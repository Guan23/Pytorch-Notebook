# _*_ coding utf-8 _*_
# developer: Guan
# time: 2021/7/20-10:30

import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as trs

if __name__ == '__main__':
    print('\n-----------------------------------------START---------------------------------------\n')

    train_data = torchvision.datasets.CIFAR10('./dataset',
                                              train=True,
                                              transform=trs.ToTensor(),
                                              download=True
                                              )

    vgg16_pretrained = torchvision.models.vgg16_bn(pretrained=True, progress=True)

    # �����Զ���������
    # vgg16_pretrained.add_module('guan01', nn.Linear(in_features=1000, out_features=10))
    # vgg16_pretrained.classifier.add_module('7', nn.Linear(1000, 10))  # ���Ӹ����ƣ��Լ������

    # �޸����е������
    vgg16_pretrained.classifier[6] = nn.Linear(4096, 10)  # ��Ӧ�����±�

    print(vgg16_pretrained)

    print('\n------------------------------------------END----------------------------------------\n')
