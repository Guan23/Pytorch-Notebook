# _*_ coding utf-8 _*_
# developer: Guan
# time: 2022/6/21-14:31
import torch
from torch import nn

'''
ONNX模型导出的几个原则：
1、对于任何用到shape啊，size啊这种参数时，加上int转换，不用管warning，这会去掉gather、shape等节点，简化操作
2、对于上采样函数，如nn.Upsample或nn.functional.interpolate等函数，使用scale_factor而不要用size来指定缩放倍率
3、对于reshape、view等操作，指定到batch维为-1，不要指定其他维度为-1，也不要对batch维指定具体数字
4、torch.onnx.export指定dynamic_axes参数时只指定batch维，别指定其他维，放心，动态宽高后期有其他方案
'''

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.conv = nn.Conv2d(1, 1, 3, stride=1, padding=1, bias=True)
        self.conv.weight.data.fill_(0.3)  # conv层的权重全部填充0.3
        self.conv.bias.data.fill_(0.2)  # conv层的偏移全部填充0.3

    # [1, 1, 4, 8] --> [1, 32]
    def forward(self, x):
        out = self.conv(x)
        # return x.view(x.shape[0], -1)
        return x.view(-1, int(x.numel() // x.shape[0]))


if __name__ == "__main__":
    print("\n----------start----------\n")
    model = Model().eval()

    x = torch.ones((1, 1, 4, 8))
    print(x.shape)
    y = model(x)
    print(y.shape)

    # 保存onnx模型，常用的参数就下面这四个
    # model显然是模型咯
    # args是模型的输入，默认为元组格式
    # f就是保存的onnx模型
    # verbose就是是否打印一些debug信息，默认False
    torch.onnx.export(model=model, args=(x, ), f="test02.onnx")

    print("\n-----------end-----------\n")
