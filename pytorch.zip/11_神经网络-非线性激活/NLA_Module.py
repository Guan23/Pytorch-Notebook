# _*_ coding utf-8 _*_
# developer: Guan
# time: 2021/7/12-12:13

import torch
from torch import nn


# ��conv2d���ƣ�ҲҪ�̳�nn.Module��Ȼ��дinit��forward
class MyNlA(nn.Module):
    def __init__(self):
        super(MyNlA, self).__init__()
        self.relu1 = nn.ReLU()
        self.sigmoid1 = nn.Sigmoid()
        self.softmax1 = nn.Softmax(3)

    def forward(self, x):
        out1 = self.relu1(x)
        out2 = self.sigmoid1(x)
        out3 = self.softmax1(x)
        return out1, out2, out3


if __name__ == '__main__':
    print('\n-----------------------------------------START---------------------------------------\n')

    # ����Ҫ��dtype��longת��float������maxpool�����޷���long���ݽ��д���
    input = torch.tensor([[1, -2, -3],
                          [2, 3, -4],
                          [3, 4, 5]], dtype=torch.float32)
    # ��״ͬ��Ҫ��ά��batch_size��channel��h��w
    input = torch.reshape(input, (-1, 1, 3, 3))

    # print(input.shape)
    mynet = MyNlA()
    output1, output2, output3 = mynet(input)
    print(output1)
    print(output2)
    print(output3)

    print('\n------------------------------------------END----------------------------------------\n')
