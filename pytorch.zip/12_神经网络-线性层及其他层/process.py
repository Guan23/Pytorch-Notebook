# _*_ coding utf-8 _*_
# developer: Guan
# time: 2021/7/12-12:13

import torch
from torch.utils.tensorboard import SummaryWriter
from torchvision import transforms
from torch import nn
import cv2 as cv


# ��ͼ�������һЩ������������tensorboard�￴һ�²������ͼ��

class MyNet(nn.Module):
    def __init__(self):
        super(MyNet, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=3, kernel_size=3, padding=1)
        self.maxpool1 = nn.MaxPool2d(kernel_size=3)
        self.relu1 = nn.ReLU()
        self.batchnorm1 = nn.BatchNorm2d(3)

    def forward(self, input):
        out1 = self.conv1(input)  # �������ͼ��
        out2 = self.maxpool1(input)  # ���ػ����ͼ��

        out3 = self.batchnorm1(input)  # �Ƚ������򻯣�Ȼ��relu
        out3 = self.relu1(out3)
        return out1, out2, out3


if __name__ == '__main__':
    print('\n-----------------------------------------START---------------------------------------\n')

    dir = "D:/My_Project/My_Datas/Pytorch_Data/single_pic/pedestrian01.jpg"
    img = cv.imread(dir)
    # cv.imshow('img', img)
    # cv.waitKey(0) & 0xff
    # cv.destroyAllWindows()

    print(type(img))
    trans_totensor = transforms.ToTensor()
    img = trans_totensor(img)
    print(type(img))
    img = torch.reshape(img, (1, 3, 866, 1280))

    mynet = MyNet()
    out1, out2, out3 = mynet(img)
    print(out1.shape)
    print(out2.shape)
    print(out3.shape)

    writer = SummaryWriter()

    img = torch.reshape(img, (3, 866, 1280))
    out1 = torch.reshape(out1, (3, 866, 1280))
    out2 = torch.reshape(out2, (3, 288, 426))
    out3 = torch.reshape(out3, (3, 866, 1280))
    writer.add_image('img', img)
    writer.add_image('conv1', out1)
    writer.add_image('maxpool1', out2)
    writer.add_image('bn1+relu1', out3)

    writer.close()

    print('\n------------------------------------------END----------------------------------------\n')
