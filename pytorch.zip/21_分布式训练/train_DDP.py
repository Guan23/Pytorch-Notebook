# 下面给出的是torch.nn.parallel.DistributedDataParallel，用mnist数据集，resnet18为例子写了一个小demo
# 比起nn.DataParallel，这才是真正的分布式训练，因为使用的是多进程，而非单进程多线程的方式，效率很高，尽管代码有点复杂，但一定要学会
# DDP的使用模式其实有多种，我们按照官方推荐的，一张卡对应一个进程的方式，给出下面的示例

# 主要有以下几步，当然顺序不一定，因为加载数据和加载模型没有先后顺序
# 一、torch.distributed.init_process_group("nccl",world_size=num_gpus,rank=args.local_rank)初始化进程组
# 二、torch.cuda.set_device(args.local_rank)设置可用的GPU，注意这里赋的实参不是手动指定的，
# 而是运行时通过命令python -m torch.distributed.launch传入的local_rank变量，需要用argparser来接收一下
# 三、net = DDP(net.cuda(args.local_rank), device_ids=[args.local_rank])模型封装
# 四、train_sampler = DistributedSampler(train_dataset)定义数据分配方式
# 五、data = data.cuda(args.local_rank)每个epoch中每批次的数据也要加载到local_rank上

# 加载数据可以像本例子中写的这样
# torch.cuda.set_device(args.local_rank)
# data = data.cuda(args.local_rank)
# 也可以这样写
# device = torch.device("cuda", args.local_rank)
# data = data.to(device)
# 看个人喜好，我自己喜欢第二种写法

# 运行命令为python -m torch.distributed.launch --nproc_per_node=2 train_dist.py
# torch.distributed.launch是为了生成local_rank这个参数的，
# --nproc_per_node指的是当前节点有多少个GPU，要跟你的CUDA_VISIBLE_DEVICES环境变量的数量一致

# 打印信息的时候也要注意，因为是多进程，直接print会打印多遍，通过if args.local_rank == 0控制只打印1遍

# os环境中，设置CUDA_VISIBLE_DEVICES变量来控制你要使用的GPU编号
import argparse

import torch
import torchvision
from torch import nn

from torch import distributed as dist
from torch.utils.data.distributed import DistributedSampler as DS
from torch.nn.parallel.distributed import DistributedDataParallel as DDP

import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"  # 按照PCI_BUS总线的顺序进行GPU的排序
os.environ["CUDA_VISIBLE_DEVICES"] = "3,4"  # 设置可见的GPU
# 上面两句环境配置当然也可以在命令行里写，以第二句为例，写法是CUDA_VISIBLE_DEVICES=3,4 python xxx.py，注意要写在一句里，不要分两句运行


BATCH_SIZE = 64  # 单卡的batchsize
TOTAL_EPOCH = 6  # 训练总轮次


def main(num_gpus, local_rank, device):

    # 1、初始化进程组，backend是多个GPU之间的通信方式，可选nccl，gloo，mpi，推荐nccl
    # world_size代表全局并行数，也就是机器数量*每个机器多少张卡
    # rank意思是当前进程在哪个GPU卡上，其值要通过python -m torch.distributed.launch从外部传入，所以写代码时，要用argparser来接收命令的输入
    dist.init_process_group(
        backend="nccl", world_size=1*num_gpus, rank=local_rank)

    # 加载数据
    trans = torchvision.transforms.Compose(
        [torchvision.transforms.ToTensor(), torchvision.transforms.Normalize((0.5,), (1.0,))])
    dataset = torchvision.datasets.MNIST(
        "./data", train=True, transform=trans, target_transform=None, download=True)

    # 4、train_sampler的定义，DDP是把所有数据平均分给了n个GPU
    # (80张照片平均分给8个GPU，每个GPU得到10张，是否打乱以及如果除不尽，余数drop_last是否舍弃都是自定义的)
    # 所以要把dataset用DistributedSampler类封装，然后再传给Dataloader
    # 要注意，DS的分配数据集方式在类定义时，就已经定义好了是否打乱(shuffle,seed,set_epoch等)，Dataloader中就不要再shuffle一遍了
    # 另外还有一点，Dataloader中的batch_size对应的是每个GPU的batchsize，不是总共的batchsize
    # 还有博主提出，DDP的训练num_workers要设置为0，否则可能会报错，暂时没测试
    train_sampler = DS(dataset)
    data_loader_train = torch.utils.data.DataLoader(
        dataset=dataset,
        batch_size=BATCH_SIZE,
        sampler=train_sampler)
    # 验证集和测试集就不需要sampler封装了，跟单卡的写法一样

    # 网络搭建，调用torchvision中的resnet18
    net = torchvision.models.resnet18(num_classes=10)
    net.conv1 = nn.Conv1d(1, 64, (7, 7), (2, 2), (3, 3), bias=False)

    # 3、跟DataParallel类似，这里也要用DDP封装一下模型，同样的，后面再想调用模型，要用net.module来代替之前的net
    # 模型和device_ids都要赋值local_rank
    # find_unused_parameters(默认False)意思是找到网络前向传播中没用到的网络层(比如有的dropout层)，
    # 没用到的网络层会视为unused_layer，如果不设置这个参数为True，可能会报错
    # 如果你很确定所有网络层都用到了，就不用设置此参数为True了，它会报一个警告，因为它会略微降低训练速度
    # net = DDP(net.cuda(local_rank), device_ids=[local_rank], find_unused_parameters=True)
    net = DDP(net.to(device), device_ids=[local_rank], find_unused_parameters=False)

    # 定义loss与opt，loss不用to(cuda)
    loss_func = nn.CrossEntropyLoss()
    opt = torch.optim.Adam(net.module.parameters(), lr=0.001)
    # 网络训练
    if local_rank == 0:
        print("-"*10, " starting training ", "-"*10)
    for epoch in range(TOTAL_EPOCH):
        if local_rank == 0:
            print("----- epoch: {}/{} -----".format(epoch, TOTAL_EPOCH))
        # 为了在每个epoch中，使每个卡得到的数据不一样，请参照DistributedSampler的源码
        # 当然，也可以通过给seed设置随机数来保证每个卡的数据不同，因为在DS源码中，最终的种子值就等于seed+epoch，你改哪个都行
        train_sampler.set_epoch(epoch)

        for i, data in enumerate(data_loader_train):
            images, labels = data
            # 5、当然，每批次的数据也要加载到local_rank上
            # images, labels = images.cuda(local_rank), labels.cuda(local_rank)
            images, labels = images.to(device), labels.to(device)
            opt.zero_grad()
            outputs = net(images)
            loss = loss_func(outputs, labels)
            loss.backward()
            opt.step()
            if i % 50 == 0 and local_rank == 0:  # 这里要判断只有local_rank为0时才打印，否则每个卡都会打印一次
                # 一个细节，打印或者log记录tensor张量的时候，要打印.item()而不是张量本身
                print("iter: {}, rank:{}, loss: {}\n".format(i, local_rank, loss.item()))

    # 保存这里注意一下，我们只在1个gpu上保存模型即可，不需要在每个gpu上保存，所以指定一个保存模型的gpu_id，一般是0，也就是第一个GPU
    if local_rank == 0:
        torch.save(net.module, "./my_net.pth")
        print("-"*10, " training finished ", "-"*10)


if __name__ == "__main__":

    print(torch.cuda.is_available())
    print(torch.cuda.device_count())

    parser = argparse.ArgumentParser()
    # 运行命令python -m torch.distributed.launch时会自动传入一个local_rank的参数，要用argparser来接收此参数
    parser.add_argument(
        "--local_rank",
        help="local device id on current node",
        default=-1,
        type=int
    )
    args = parser.parse_args()
    local_rank = args.local_rank
    print("local_rank: {}".format(local_rank))

    # 2、相当于DataParallel中设置CUDA_VISIBLE_DEVICES环境变量
    # torch.cuda.set_device(local_rank)   
    device = torch.device("cuda", local_rank)
    num_gpus = torch.cuda.device_count()

    main(num_gpus, local_rank, device)
