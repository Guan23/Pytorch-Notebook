# 单机多卡训练，用torch.nn.DataParallel来举例实现，其实这个库快要被淘汰了，
# 因为它的性能缺点比较多，比如GPU显存分配不均(第一个GPU占用的显存明显大于其他gpu)，单进程(多线程)效率慢，不支持多机训练，不支持模型参数的并行
# 而其优点就只有一个，代码简单
# 其工作原理就是所有的数据先load到第一个GPU(主GPU)上，然后再分发给其他GPU去train，
# 所以此时第一个GPU的显存占用很大，你想提升batch_size,那你的主GPU就会限制你的batch_size，所以其实多卡提升速度的效果很有限

# 实际中更多使用的是torch.nn.parallel.DistributedDataParallel，既支持单机多卡，又支持多机多卡，缺点就是代码比较复杂
# 下面给出的是torch.nn.DataParallel，用mnist数据集，resnet18为例子写了一个小demo

# 1、os环境中，设置CUDA_VISIBLE_DEVICES变量来控制你要使用的GPU编号
# 实际工作中，很多时候都是2,3个人共用8个gpu这样子，同事间的代码水平参差不齐，别人可能用nn.DataParallel的代码，占用了0号GPU
# 如果你也把0号GPU作为主GPU，一旦cuda out of memory了，不仅你的代码跑不成，同事跑了一半的代码可能也会挂掉，所以最好把0号GPU空出来
import os
# 这两句环境变量的配置尽量写在代码开头部分，因为后面很多库函数都会调用到环境变量
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"  # 按照PCI_BUS总线的顺序进行GPU的排序
os.environ["CUDA_VISIBLE_DEVICES"] = "3,4"  # 设置可见的GPU
# 上面两句环境配置当然也可以在命令行里写，以第二句为例，写法是CUDA_VISIBLE_DEVICES=3,4 python xxx.py，注意要写在一句里，不要分两句运行

import torch
import torchvision
import torch.nn
import torch.utils.data.distributed
from torchvision import transforms

BATCH_SIZE = 128  # 这里设置的是单卡的batchsize
TOTAL_EPOCH = 3  # 训练总轮次
device_ids = [0, 1]  # 这里是在VISIBLE_DEVICES的基础上，再设置要用来训练的GPU卡，注意编号从0开始，并非是原GPU的编号


def main(device, num_gpus, device_ids):
    # 数据加载部分，直接利用torchvision中的datasets
    trans = transforms.Compose(
        [transforms.ToTensor(), transforms.Normalize((0.5,), (1.0,))])
    data_set = torchvision.datasets.MNIST(
        "./data", train=True, transform=trans, target_transform=None, download=True)
    # 2、train的batchsize这里要记住乘上GPU的数量，因为这里的batch_size接收的是总共的batchsize
    data_loader_train = torch.utils.data.DataLoader(
        dataset=data_set, batch_size=num_gpus*BATCH_SIZE)
    # 网络搭建，调用torchvision中的resnet18
    net = torchvision.models.resnet18(num_classes=10)
    net.conv1 = torch.nn.Conv1d(1, 64, (7, 7), (2, 2), (3, 3), bias=False)
    # 3、这种方法简单就在于此，只需在net.to(device)之后再用nn.DataParallel封装一层即可，记得设置device_ids
    # 要注意这里的device_ids要从0开始，并不是最初的GPU编号，比如你有8个GPU，初始编号是0~7
    # 你前面又设置了CUDA_VISIBLE_DEVICES="3,4,5,6"，那么此时3号gpu的device_id就是0，4号gpu的device_id就是1，以此类推
    # 这里对模型用nn.DataParallel封装之后，接下来都要用net.module来代替之前的net了，具体可以看DataParallel类的构造函数
    # 其实还有一个output_device的初始化参数没写，默认是主gpu，也就是可见GPU中的0号gpu，一般也懒得换了
    net = torch.nn.DataParallel(net.to(device), device_ids=device_ids)

    # 定义loss与opt
    loss_func = torch.nn.CrossEntropyLoss()
    loss_func.to(device)
    opt = torch.optim.Adam(net.module.parameters(), lr=0.001)
    # 网络训练
    print("-"*10, " starting training ", "-"*10)
    for epoch in range(TOTAL_EPOCH):
        print("----- epoch: {}/{} -----".format(epoch, TOTAL_EPOCH))
        for i, data in enumerate(data_loader_train):
            images, labels = data
            images, labels = images.to(device), labels.to(device)
            opt.zero_grad()
            outputs = net(images)
            loss = loss_func(outputs, labels)
            loss.backward()
            opt.step()
            if i % 100 == 0:
                print("loss: {}".format(loss.item()))  # 一个细节，打印或者log记录tensor张量的时候，要打印.item()而不是张量本身
    # 4、保存checkpoint这里也要注意一下，因为对模型用nn.DataParallel封装了一层，所以它的module成员变量才是最初的model模型
    torch.save(net.module, "./my_net.pth")
    print("-"*10, " training finished ", "-"*10)


if __name__ == "__main__":
    print(torch.cuda.is_available())
    print(torch.cuda.device_count())

    device = "cuda" if torch.cuda.is_available() else "cpu"
    assert device == "cuda", "没有GPU你训练个毛线啊？"

    num_gpus = torch.cuda.device_count()
    assert len(device_ids)<=num_gpus,"大哥，你想多了，你没那么多GPU!"
    
    main(device, num_gpus, device_ids)
